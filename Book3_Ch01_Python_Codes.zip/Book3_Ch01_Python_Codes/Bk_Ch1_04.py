
###############
# Authored by Weisheng Jiang
# Book 3  |  From Basic Arithmetic to Machine Learning
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2022
###############

# Bk_Ch1_04

num1 = 2
num2 = 3

# add two numbers
sum = num1 + num2

# display the computation
print('The sum of {0} and {1} is {2}'.format(num1, num2, sum))
