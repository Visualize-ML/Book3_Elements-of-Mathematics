
###############
# Authored by Weisheng Jiang
# Book 3  |  From Basic Arithmetic to Machine Learning
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2022
###############

# Bk_Ch2_04

num1 = 6
num2 = 3

# add two numbers
division = num1/num2

# display the computation
print('The division of {0} over {1} is {2}'.format(num1, num2, division))
