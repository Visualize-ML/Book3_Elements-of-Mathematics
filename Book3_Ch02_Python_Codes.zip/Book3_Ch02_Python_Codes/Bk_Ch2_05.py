
###############
# Authored by Weisheng Jiang
# Book 3  |  From Basic Arithmetic to Machine Learning
# Published and copyrighted by Tsinghua University Press
# Beijing, China, 2022
###############

# Bk_Ch2_05

num1 = 7
num2 = 2

# add two numbers
remainder = num1%num2

# display the computation
print('The remainder of {0} over {1} is {2}'.format(num1, num2, remainder))
